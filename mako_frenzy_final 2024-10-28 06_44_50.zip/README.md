# MAKO Frenzy Flask App

A simple Flask app for report management using Microsoft OneDrive.